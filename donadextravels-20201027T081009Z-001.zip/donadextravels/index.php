<?php
    include 'include/header.php';
?>

<!--Top banner-->
<div class="top-banner">

</div>
<!--Banner-->
<div class="banner-wrap">
    <div class="booking-engine">
        <div class="col-md-12 ibe">
            <iframe id='travelstartIframe-443947c0-8955-460a-992c-953ee6074ec8' frameBorder='0' scrolling='no' style='margin: 0px; padding: 0px; border: 0px; height: 0px; background-color: #fafafa;'>
            </iframe>
        </div>
    </div>
    <div class="flights">
        <div class="flights-left">
            <h3>Popular Flights</h3>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Dubai</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 172,000</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>New York</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 285,411</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Paris</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 179,462</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Accra</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 121,058</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Johannesburg</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 152,000</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Kigali</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 122,660</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Abuja</h5>
                <hr />
                <h5>ROUND TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 48,198</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Abuja</h5>
                <hr />
                <h5>ONE-WAY TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 24,099</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <div class="col-md-4 flight-item">
                <h5>Lagos</h5>
                <h5>Benin</h5>
                <hr />
                <h5>ONE-WAY TRIP</h5>
                <div class="price"><sup style="color: #ff4000"><em>from</em></sup>NGN 23,499</div>
                <p><sup>*</sup>Subject to Availability</p>
                <div class="book" data-toggle="modal" data-target="#liveBooking">Book Now</div>
            </div>
            <br /><br />
            <h3>Hotel Deals</h3>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/dubai.jpg" alt="dubai hotels" />
                <h6>DUBAI</h6>
            </div>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/newyork.jpg" alt="newyork hotels" />
                <h6>NEW YORK</h6>
            </div>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/paris.jpg" alt="paris hotels" />
                <h6>PARIS</h6>
            </div>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/accra.jpg" alt="accra hotels" />
                <h6>ACCRA</h6>
            </div>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/nairobi.jpg" alt="nairobi hotels" />
                <h6>NAIROBI</h6>
            </div>
            <div class="col-md-4 flight-item hotel-item">
                <img src="images/johannesburg.jpg" alt="johannesburg hotels" />
                <h6>JOHANNESBURG</h6>
            </div>
        </div>
        <div class="flights-right">
            <div class="col-md-12 advert">
                <img src="images/ads2.jpg" alt="dubai visa advert" />
            </div>
            <div class="col-md-12 advert" data-toggle="modal" data-target="#liveBooking">
                <img src="images/ads1.jpg" alt="cheap tickets" />
            </div>
        </div>
    </div>

</div>

<div class="clearfix"></div>

<?php
    include'include/footer.php';
?>
